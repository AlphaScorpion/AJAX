
<?php

echo 'hello everyone';			


?>